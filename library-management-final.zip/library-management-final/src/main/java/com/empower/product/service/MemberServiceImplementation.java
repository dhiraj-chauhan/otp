package com.empower.product.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailParseException;
//import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.empower.product.entity.AdminLogin;
import com.empower.product.entity.Login;
import com.empower.product.entity.Member;
import com.empower.product.entity.MemberCode;
import com.empower.product.repository.AdminLoginRepository;
import com.empower.product.repository.LoginRepository;
import com.empower.product.repository.MemberRepository;

import javax.mail.MessagingException;
//import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;



@Service
public class MemberServiceImplementation implements MemberService {
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	LoginRepository loginRepository;
	@Autowired
	AdminLoginRepository adminLoginRepository;
	
	@Autowired
	JavaMailSender mailSender;

	@Override
	public MemberCode addMember(Member member) {
		MemberCode memberCode = new MemberCode(0,"Member not Found", null);
		if(!memberRepository.existsById(member.getMemberId())) {
			memberRepository.save(member);
		   Login login = new Login(member.getUsername(), member.getPassword());
		   loginRepository.save(login);
		   
		   generateOtp(member.getEmail(),member.getUsername());
			memberCode.setStatus(1);
			memberCode.setMessage("Member Added");
			memberCode.setMember(member);
		}
		
		return memberCode;
	}

	@Override
	public MemberCode getLoginDetails(Login l) {
		MemberCode memberCode = new MemberCode(0,"Member not found", null);            
		Optional<Login> x = loginRepository.findById(l.getUsername()) ;

		Login log = x.get();
		
		if(x.isPresent() && log.getPin()==1)
		{
			if(log.getPassword().equals(l.getPassword())) {
				memberCode.setMessage("Login Successfull");
				memberCode.setLogin(l);
				memberCode.setStatus(1);
				
			}
					
		}

		return memberCode;
	}

	@Override
	public List<Member> getAllMembers() {
		List<Member> members = memberRepository.findAll();
		return members;
	}

	@Override                                        
	public MemberCode getAdminLoginDetails(AdminLogin l) {
		MemberCode memberCode = new MemberCode(0, null,"Admin Not found");
	
		                                                         
		Optional<AdminLogin> x = adminLoginRepository.findById(l.getUsername()) ;

		AdminLogin log = x.get();
		if(x.isPresent()  )
		{
			if(log.getPassword().equals(l.getPassword())) {
				memberCode.setMessage("Login Successfull");
				memberCode.setAdminLogin(l);
				memberCode.setStatus(1);
				
			}
					
		}

		return memberCode;
	}

	@Override
	public List<Member> getMemberForLogin(String username) {
	
		List<Member> member = memberRepository.findByUsername(username);
		return member;
	}

	@Override
	public String checkverify(String username) {
		System.out.println(username);
		Login x = loginRepository.findByUsername(username);
		
		if(x == null) {
		return("Verification Failed");
		}
		x.setPin(1);
		loginRepository.save(x);
		return ("Verification Sucessfull");
	}
	
	// email service
	
	public String generateOtp(String email, String username)
	{
		System.out.println("email sending");
		String url = "http://localhost:5000/member/verify/"+username;
		sendEmailToUsers(email,"verification link",username,url);

	return"two";

	}


	public void sendEmailToUsers(String emailId,String subject, String name, String url){
		String result =null;
		MimeMessage message =mailSender.createMimeMessage();
		try {

			MimeMessageHelper helper = new MimeMessageHelper(message, false, "utf-8");
			String htmlMsg = "<body style='border:2px solid black'>"
					+"Your onetime password for registration is  "
					+ "Please use this OTP to complete your new user registration."+
					 "<a href ="+ url  + "> Verify </a> " +
					"OTP is confidential, do not share this  with anyone.</body>";
			message.setContent(htmlMsg, "text/html");
			helper.setTo(emailId);
			helper.setSubject(subject);
			result="success";
			mailSender.send(message);
		} catch (MessagingException e) {
			throw new MailParseException(e);
		}finally {
			if(result !="success"){
				result="fail";
			}
		}

	

	}




	

	}
